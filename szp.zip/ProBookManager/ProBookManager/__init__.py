# 导入mysql驱动
import  pymysql
pymysql.install_as_MySQLdb()