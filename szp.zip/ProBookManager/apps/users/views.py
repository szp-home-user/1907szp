from django.shortcuts import render,reverse,redirect
from django.http import  request,HttpResponse,JsonResponse,HttpResponseRedirect
from django.views.generic.base import View #或from django.views.generic import View
from .models import  Users
from django.contrib  import  auth  # 导入django自带的认证模块（包含很多方法）

class RegisterView(View):
    def get(self, request):
        return render(request,'register.html')
    def post(self,request):
        '''1. 获取用户资料2. 封装为user对象3. 增加功能
        '''
        user_grade = request.POST.get('user_grade') #角色编号
        user_name= request.POST.get('user_name') #用户名
        user_password = request.POST.get('user_password') #密码
        user_phone = request.POST.get('user_phone') #电话
        user_email = request.POST.get('user_email')# 邮箱
        print(f'角色:{user_grade},名字:{user_name},邮箱:{user_email},密码:{user_password}')

        # django认证体系用户模块自带功能（必填）
        u = Users.objects.create_user(username=user_name,password=user_password,email=user_email)
        u.phone = user_phone # 通过对象属性可以更改扩展的列值
        u.roleid = user_grade
        if user_grade =="1":
            u.is_superuser = 1
        u.save() #存储修改
        return render(request,'index.html')


#登录功能
def do_login(request):
    user_name = request.POST.get('user_name')
    user_password = request.POST.get('user_password')
    print(f'用户名：{user_name},密码:{user_password}')
    u = auth.authenticate(username=user_name,password=user_password)
    if u is not None:
        print(f'登录成功：{u.username}')
        # 用户资料手动写在session中
        # request.session['username'] = user_name
        auth.login(request,u)

        # request.user 固定语法！获取认证体系中的session数据！
        print(request.user)  # 返回用户名
        print(request.user.username) # user.username 返回用户名
        print(request.user.password) # 获取其他属性
        print(request.user.roleid)  # 获取其他属性
    else:
        print('用户名或密码错误')
    return HttpResponse('登录实现')

#首页
def index(request):
    return render(request,'index.html')

#首页
def add(request):
    return HttpResponse('增加用户')


def logout(request):
    auth.logout(request) #注销功能，自动清除session中的用户资料
    return render('/')