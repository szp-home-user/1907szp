
from django.contrib import admin
from django.urls import path
from . import  views
# 应用名
app_name = 'users'
urlpatterns = [
    path('add', views.add,name='add'),# /users/add
    path('register', views.RegisterView.as_view(),name='register'),# /users/register
    path('login', views.do_login,name='login'),# /users/login
    path('logout', views.logout,name='logout'),# /users/logout

]
