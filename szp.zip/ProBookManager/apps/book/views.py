from django.shortcuts import render,reverse
from django.http import  request,HttpResponse,HttpResponseRedirect,JsonResponse
from  .models import  Book
from django.contrib.auth.decorators import login_required #django自带登录装饰器
# 书籍列表

def list(request):
    books = Book.objects.all()
    # 传参数
    context = {'books':books}
    print(books)
    return render(request,'book.html',context=context)

def add(request):
    return HttpResponse('增加书籍')

def del_book (request):
    '''删除书籍
      根据id删除，获取id，先查，再删，重定向到list
    '''
    id = request.GET.get('id')
    print('删除',id)
    book = Book.objects.get(id=id)
    book.delete()
    return HttpResponseRedirect(reverse('book:list'))  # 反转找到对应方法

def del_book2 (request,id):
    '''删除书籍
      根据id删除，获取id，先查，再删，重定向到list
    '''
    print('删除2', id)
    book =Book.objects.get(id=id)
    book.delete()
    return HttpResponseRedirect(reverse('book:list')) # 反转找到对应方法

