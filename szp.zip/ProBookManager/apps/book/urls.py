
from django.contrib import admin
from django.urls import path
from . import  views
# 应用名
app_name = 'book'
urlpatterns = [
    path('list', views.list,name='list'),# /book/list
    path('add', views.add,name='add'),# /book/add
    path('del', views.del_book,name='del'),# /book/add
    path('del2/<id>', views.del_book2,name='del2'),# /book/ad d
]
