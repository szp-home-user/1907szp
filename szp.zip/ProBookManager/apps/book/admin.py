from django.contrib import admin
from .models import  Book,Author
# Register your models here.
# 注册     你的  模型类
admin.site.register(Book)
admin.site.register(Author)